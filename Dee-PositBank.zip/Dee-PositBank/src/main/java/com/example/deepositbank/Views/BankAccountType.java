package com.example.deepositbank.Views;

public enum BankAccountType {

    REWARD_ACCOUNT,
    BASIC_ACCOUNT,
    ISA_ACCOUNT
}
