package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Models.Customer;

import java.util.ArrayList;
import java.util.List;

public class CustomerManager {
    private final List<Customer> customerList;


    public CustomerManager() {
        // Initialize the list of customers
        customerList = new ArrayList<>();
        // Add sample customers or load them from a data source
        // customerList.add(new Customer(...));
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void addCustomer(Customer customer) {
        customerList.add(customer);
    }

    public void deleteCustomer(Customer customer) {
        customerList.remove(customer);
    }

    public void editCustomer(Customer customer, String newFirstName, String newLastName) {
        // Logic to edit the customer details
        customer.setFirstName(newFirstName);
        customer.setLastName(newLastName);
        // Other property edits if needed...
    }

    // Other methods to update or manage customers
}