package com.example.deepositbank.Views;

import com.example.deepositbank.Controllers.AccountManager.CustomerCellController;
import com.example.deepositbank.Models.Customer;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListCell;

public class CustomerCellFactory extends ListCell<Customer> {

    @Override
    protected void updateItem(Customer customer, boolean empty) {
        super.updateItem(customer, empty);
        if(empty){
            setText(null);
            setGraphic(null);
        }else{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Fxml/AccountManager/CustomerCell"));
            CustomerCellController controller = new CustomerCellController(customer);
            loader.setController(controller);
            setText(null);
            try {
                setGraphic(loader.load());
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
