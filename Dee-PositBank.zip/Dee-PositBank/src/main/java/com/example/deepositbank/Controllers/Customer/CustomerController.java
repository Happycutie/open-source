package com.example.deepositbank.Controllers.Customer;

import com.example.deepositbank.Models.Model;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomerController implements Initializable {

    public BorderPane customer_parent;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Model.getInstance().getViewFactory().getCustomerSelectedMenuItem().addListener((observableValue, oldVal, newVal )  -> {
            switch (newVal){
                case TRANSACTIONS -> customer_parent.setCenter(Model.getInstance().getViewFactory().getTransactionsViews());
                case ACCOUNTS -> customer_parent.setCenter(Model.getInstance().getViewFactory().getAccountsView());
                case PROFILE -> customer_parent.setCenter(Model.getInstance().getViewFactory().getProfileView());
                case SETTING -> customer_parent.setCenter(Model.getInstance().getViewFactory().getSettingView());
                default -> customer_parent.setCenter(Model.getInstance().getViewFactory().getDashboardView());

        }
        });
    }
}
