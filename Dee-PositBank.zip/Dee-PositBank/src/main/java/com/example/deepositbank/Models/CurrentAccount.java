package com.example.deepositbank.Models;

import javafx.beans.binding.BooleanExpression;
import javafx.beans.value.ObservableValue;

public interface CurrentAccount {
    void processCardTransaction(int amount);

    BooleanExpression balanceProperty();

    ObservableValue<String> accountNumberProperty();

    double getBalance();
}
