package com.example.deepositbank.Models;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class IsaAccount extends Account implements SavingsAccount {
    private final StringProperty type;
    private final IntegerProperty interestRate;

    public IsaAccount(String accountNumber, String sortCode, int balance) {
        super(accountNumber, sortCode, balance);
        this.type = new SimpleStringProperty("ISA");
        this.interestRate = new SimpleIntegerProperty(0); // Default interest rate set to 0
    }

    public String getType() {
        return type.get();
    }

    public StringProperty typeProperty() {
        return type;
    }

    @Override
    public void applyInterest() {
        // Logic for applying interest to an ISA account
        // Implement your specific logic here
    }

    @Override
    public int getInterestRate() {
        // Logic to get the interest rate of an ISA account
        return interestRate.get();
    }

    @Override
    public void setInterestRate(int rate) {
        // Logic to set the interest rate of an ISA account
        interestRate.set(rate);
    }

    public IntegerProperty interestRateProperty() {
        return interestRate;
    }

    public StringProperty accountNumberProperty() {
        // Implement your logic here
        return null; // Replace with actual logic
    }

    // Example placeholder for visaProperty
    public StringProperty visaProperty() {
        // Implement your logic here
        return null; // Replace with actual logic
    }
}