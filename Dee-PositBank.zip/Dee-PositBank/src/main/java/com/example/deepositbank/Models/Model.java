package com.example.deepositbank.Models;


import com.example.deepositbank.Views.ViewFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.time.LocalDate;

public class Model {
    private static Model model;
    private final ViewFactory viewFactory;

    private final DatabaseDriver databaseDriver;

    // Customer Data Section
    private final Customer customer;
    private boolean customerLoginSuccessFlag;
    private final ObservableList<Transaction> latestTransactions;
    private final ObservableList<Transaction> allTransactions;

    // AccountManager Data Section
    private boolean accountManagerLoginSuccessFlag;
    private final ObservableList<Customer> customers;

    private Model() {
        this.viewFactory = new ViewFactory();
        this.databaseDriver = new DatabaseDriver();
        // Customer Data Section
        this.customerLoginSuccessFlag = false;
        this.customer = new Customer("", "", "", "", null, null, null, null,null);
        this.latestTransactions = FXCollections.observableArrayList();
        this.allTransactions = FXCollections.observableArrayList();
        // Admin Data Section
        this.accountManagerLoginSuccessFlag = false;
        this.customers = FXCollections.observableArrayList();
    }

    public static synchronized Model getInstance() {
        if (model == null) {
            model = new Model();
        }
        return model;
    }

    public ViewFactory getViewFactory() {
        return viewFactory;
    }

    public DatabaseDriver getDatabaseDriver() {return databaseDriver;}

    /*
     * Customer Method Section
     * */
    public boolean getCustomerLoginSuccessFlag() {
        return this.customerLoginSuccessFlag;
    }

    public void setCustomerLoginSuccessFlag(boolean flag) {
        this.customerLoginSuccessFlag = flag;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void evaluateCustomerCred(String aNumber, String sCode String password) {
        RewardAccount rewardAccount;
        BasicAccount basicAccount;
        IsaAccount isaAccount;
        ResultSet resultSet = databaseDriver.getCustomerData(aNumber, sCode, password);
        try {
            if (resultSet.isBeforeFirst()) {
                this.customer.firstNameProperty().set(resultSet.getString("FirstName"));
                this.customer.lastNameProperty().set(resultSet.getString("LastName"));
                this.customer.aNumber().set(resultSet.getString("Account Number"));
                this.customer.sortCodeProperty().set(resultSet.getString("Sort Code"));
                String[] dateParts = resultSet.getString("Date").split("-");
                LocalDate date = LocalDate.of(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2]));
                this.customer.dateProperty().set(date);
                rewardAccountProperty = getRewardAccount(aNumber);
                basicAccountProperty = getBasicAccount(aNumber);
                isaAccountProperty = getIsaAccount(aNumber);
                this.customer.rewardAccountProperty().set(rewardAccount);
                this.customer.basicAccountProperty().set(basicAccount);
                this.customer.isaAccountProperty().set(isaAccount);
                this.customerLoginSuccessFlag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        private void prepareTransactions(ObservableList<Transaction> transactions, int limit) {
            ResultSet resultSet = databaseDriver.getTransactions(this.customer.accountNumberProperty().sortCodeProperty.get(), limit);
            try {
                while (resultSet.next()) {
                    String sender = resultSet.getString("Sender");
                    String receiver = resultSet.getString("Receiver");
                    double amount = resultSet.getDouble("Amount");
                    String[] dateParts = resultSet.getString("Date").split("-");
                    LocalDate date = LocalDate.of(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2]));
                    String message = resultSet.getString("Message");
                    transactions.add(new Transaction(sender, receiver, amount, date, message));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void setLatestTransactions() {
        prepareTransactions(this.latestTransactions, 4);
    }

    public ObservableList<Transaction> getLatestTransactions() {
        return latestTransactions;
    }

    public void setAllTransactions() {
        prepareTransactions(this.allTransactions, -1);
    }

    public ObservableList<Transaction> getAllTransactions() {
        return allTransactions;
    }

    /*

    /*
     * AccountManager Method Section
     * */

    public boolean getAccountManagerLoginSuccessFlag() {return this.accountManagerLoginSuccessFlag;}

    public void setAccountManagerLoginSuccessFlag(boolean accountManagerLoginSuccessFlag) {
        this.accountManagerLoginSuccessFlag = accountManagerLoginSuccessFlag;
    }

    public void evaluateAccountManagerCred(String username, String password) {
        ResultSet resultSet = databaseDriver.getAccountManagerData(username, password);
        try {
            if (resultSet.isBeforeFirst()){
                this.accountManagerLoginSuccessFlag = true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public ObservableList<Customer> getCustomers() {
        return customers;
    }

    public  void setCustomers(){
        RewardAccount rewardAccount;
        BasicAccount basicAccount;
        IsaAccount isaAccount;
        ResultSet resultSet = databaseDriver.getAllCustomersData();
        try {
            while (resultSet.next()){
                String fName = resultSet.getString("FirstName");
                String lName = resultSet.getString("LastName");
                String aNumber = resultSet.getString("AccountNumber");
                String sCode = resultSet.getString("Sort Code");
                String[] dateParts = resultSet.getString("Date").split("-");
                LocalDate date = LocalDate.of(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2]));
                rewardAccount = getRewardAccount(aNumber, sCode);
                basicAccount  = getBasicAccount(aNumber, sCode);
                isaAccount = getIsaAccount(aNumber, sCode);
                customers.add(new Customer(fName, lName, aNumber, sCode, rewardAccount,basicAccount,isaAccount,date));
    }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public ObservableList<Customer> searchCustomer(String aNumber){
        ObservableList<Customer> searchResults = FXCollections.observableArrayList();
        ResultSet resultSet = databaseDriver.searchCustomer(aNumber);
        try {
            RewardAccount rewardAccount= getRewardAccount(aNumber);
            BasicAccount  basicAccount = getBasicAccount(aNumber);
            IsaAccount   isaAccount = getIsaAccount(aNumber);
            String fName = resultSet.getString("FirstName");
            String lName = resultSet.getString("LastName");
            String[] dateParts = resultSet.getString("Date").split("-");
            LocalDate date = LocalDate.of(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2]));
            searchResults.add(new Customer(fName, lName, aNumber, rewardAccount, basicAccount,isaAccount, date));
        }catch (Exception e){
            e.printStackTrace();
        }
        return searchResults;
    }

/*
 * Utility Methods Section
 * */

    public RewardAccount getRewardAccount(String aNumber) {
        RewardAccount account = null;
        ResultSet resultSet = databaseDriver.getRewardAccountData(aNumber);
        try {
            String num = resultSet.getString("AccountNumber");
            int tLimit = (int) resultSet.getDouble("TransactionLimit");
            double balance = resultSet.getDouble("Balance");
            account = new RewardAccount(aNumber, num, balance, tLimit);
        }catch (Exception e){
            e.printStackTrace();
        }
        return account;
    }
    public BasicAccount getBasicAccount(String aNumber) {
        BasicAccount account = null;
        ResultSet resultSet = databaseDriver.getBasicAccountData(aNumber);
        try {
            String num = resultSet.getString("AccountNumber");
            double wLimit = resultSet.getDouble("WithdrawalLimit");
            double balance = resultSet.getDouble("Balance");
            account = new RewardAccount(aNumber, num, balance, wLimit);
        }catch (Exception e){
            e.printStackTrace();
        }
        return account;
    }

    public IsaAccount getIsaAccount(String aNumber) {
        IsaAccount account = null;
        ResultSet resultSet = databaseDriver.getIsaAccountData(aNumber);
        try {
        String num = resultSet.getString("AccountNumber");
        int tLimit = (int) resultSet.getDouble("TransactionLimit");
        double balance = resultSet.getDouble("Balance");
        account = new IsaAccount(aNumber, num, balance, tLimit);
        }catch (Exception e){

        e.printStackTrace();
        }
        return account;
        }

}
