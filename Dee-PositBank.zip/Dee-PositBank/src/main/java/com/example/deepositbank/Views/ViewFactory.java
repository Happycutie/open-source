package com.example.deepositbank.Views;

import com.example.deepositbank.Controllers.AccountManager.AccountManagerController;
import com.example.deepositbank.Controllers.Customer.CustomerController;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ViewFactory {

    private AccountType loginAccountType;

    //customer views

    private final ObjectProperty<CustomerMenuOptions> customerSelectedMenuItem;
    private AnchorPane dashboardView;
    private AnchorPane transactionsViews;

    private AnchorPane accountsView;

    private AnchorPane profileView;

    private AnchorPane settingView;


    //AccountManager views
    private final ObjectProperty<AccountManagerMenuOptions> accountManagerSelectedMenuItem;
    private AnchorPane addNewCustomerView;
    private AnchorPane customersView;

    private AnchorPane depositView;

    public ViewFactory() {
        this.loginAccountType = AccountType.CUSTOMER;
        this.customerSelectedMenuItem = new SimpleObjectProperty<>();
        this.accountManagerSelectedMenuItem = new SimpleObjectProperty<>();

    }

    public AccountType getLoginAccountType() {
        return loginAccountType;
    }

    public void setLoginAccountType(AccountType loginAccountType) {
        this.loginAccountType = loginAccountType;
    }

    //Customer View section
    public ObjectProperty<CustomerMenuOptions> getCustomerSelectedMenuItem() {
        return customerSelectedMenuItem;
    }


    public AnchorPane getDashboardView() {
        if (dashboardView == null) {
            try {
                dashboardView = new FXMLLoader(getClass().getResource("/Fxml/Customer/Dashboard.fxml")).load();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return dashboardView;
    }


    public AnchorPane getTransactionsViews() {
        if (transactionsViews == null){
            try{
                transactionsViews = new  FXMLLoader(getClass().getResource("/Fxml/Customer/Transactions.fxml")).load();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return transactionsViews;
    }


    public AnchorPane getAccountsView() {
        if (accountsView == null){
            try{
                accountsView = new FXMLLoader(getClass().getResource("/Fxml/Customer/Accounts.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return accountsView;
    }

    public AnchorPane getProfileView() {
        if (profileView == null){
            try{
                profileView = new FXMLLoader(getClass().getResource("/Fxml/Customer/Profile.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return profileView;
    }

    public AnchorPane getUpdateAccountView() {
        if (settingView == null){
            try{
                settingView = new FXMLLoader(getClass().getResource("/Fxml/Customer/UpdateAcct.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return settingView;
    }






    public void showCustomerWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Fxml/Customer/Customer.fxml"));
        CustomerController customerController = new CustomerController();
        loader.setController(customerController);
        createStage(loader);
    }

    //Account manager view section

    public ObjectProperty<AccountManagerMenuOptions> getAccountManagerSelectedMenuItem(){
        return accountManagerSelectedMenuItem;
    }

    public AnchorPane getAddNewCustomerView() {
        if (addNewCustomerView == null){
            try{
                addNewCustomerView = new FXMLLoader(getClass().getResource("/Fxml/AccountManager/AddNewCustomer.fxml")).load();

            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return addNewCustomerView;

    }

    public AnchorPane getCustomersView() {
       if (customersView == null){
           try{
               customersView = new FXMLLoader(getClass().getResource("/Fxml/AccountManager/Customers.fxml")).load();

           }catch (Exception e){
               e.printStackTrace();
           }
       }
       return customersView;
    }

    public AnchorPane getDepositView(){
        if(depositView == null) {
            try {
                depositView = new FXMLLoader(getClass().getResource("/Fxml/AccountManager/Deposit.fxml")).load();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return depositView;
        }



    public void showAccountManagerWindow(){
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Fxml/AccountManager/AccountManager.fxml"));
        AccountManagerController controller = new AccountManagerController();
        loader.setController(controller);
        createStage(loader);
    }

    public void showLoginWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Fxml/Login.fxml"));
        createStage(loader);
    }

    private void createStage(FXMLLoader loader) {
        Scene scene = null;
        try {
            scene = new Scene(loader.load());
            // Some potential code that might throw an exception
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception here if needed
        }

        // Stage creation after the catch block
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/Images/icon.png"))));
        stage.setResizable(false);
        stage.setTitle("Dee-PositBank");
        stage.show();
    }

    public void closeStage(Stage stage) {
        stage.close();

    }}


