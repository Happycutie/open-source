package com.example.deepositbank.Controllers.Customer;

import com.example.deepositbank.Models.Customer;
import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Models.Transaction;
import com.example.deepositbank.Views.TransactionCellFactory;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.net.URL;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    public Text user_name;
    public Label login_date;
    public Label Bank_acc_type_bal;
    public Label bank_acc_type_num;
    public Text Bank_acc_type;

    public Label income_lbl;
    public Label expense_lbl;
    public ListView<Transaction>transaction_listview;
    public TextField bank_acc_fld;
    public TextField amount_fld;
    public TextArea message_fld;
    public Button Send_money_btn;
    public TextField sort_code_fld;
    public Label card_number;

    public Text account_Type_Label_fld;
    public Label balance;
    public Label acc_num;
    public Label visa_amount;
    public Label visa_bal;



    private Customer customer; // Placeholder for your Customer class

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customer = Model.getInstance().getCustomer(); // Get customer data

        bindData();
        initLatestTransactionsList();
        transaction_listview.setItems(Model.getInstance().getLatestTransactions());
        transaction_listview.setCellFactory(e -> new TransactionCellFactory());
        Send_money_btn.setOnAction(event -> onSendMoney());
        accountSummary();
    }

    private void bindData() {
        user_name.setText("Hi, " + customer.getFirstName());
        login_date.setText("Today, " + LocalDate.now());

        // Bind Reward Account data
        Bank_acc_type.setText("Reward Account");
        Bank_acc_type_bal.textProperty().bind(customer.rewardAccountProperty().get().balanceProperty().asString());
        bank_acc_type_num.textProperty().bind(customer.rewardAccountProperty().get().accountNumberProperty());

        // Bind Basic Account data
        account_Type_Label_fld.setText("Basic Account");
        balance.textProperty().bind(customer.basicAccountProperty().get().balanceProperty().asString());
        acc_num.textProperty().bind(customer.basicAccountProperty().get().accountNumberProperty());

        account_Type_Label_fld.setText("ISA Account");
        balance.textProperty().bind(customer.isaAccountProperty().get().balanceProperty().asString());
        acc_num.textProperty().bind(customer.isaAccountProperty().get().accountNumberProperty());
        // Add any other labels or properties specific to the ISA Account

        // Bind Visa Card data
        visa_amount.textProperty().bind(customer.visaCardProperty().get().balanceProperty().asString());
        card_number.textProperty().bind(customer.visaCardProperty().get().accountNumberProperty());
    }

    private void initLatestTransactionsList() {
        if (Model.getInstance().getLatestTransactions().isEmpty()){
            Model.getInstance().setLatestTransactions();
        }
    }

    private void onSendMoney() {
        String receiver = bank_acc_fld.getText();
        double amount = Double.parseDouble(amount_fld.getText());
        String message = message_fld.getText();
        String sender = Model.getInstance().getCustomer().accountNumberProperty().get();
        ResultSet resultSet = Model.getInstance().getDatabaseDriver().searchCustomer(receiver);
        try {
            if (resultSet.isBeforeFirst()){
                Model.getInstance().getDatabaseDriver().updateBalance(receiver, amount, "ADD");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        // Subtract from sender's savings account
        Model.getInstance().getDatabaseDriver().updateBalance(sender, amount, "SUB");
        // Update the savings account balance in the client object
        Model.getInstance().getCustomer().rewardAccountProperty().get().setBalance(Model.getInstance().getDatabaseDriver().getRewardAccountBalance(sender));
        // Record new transaction
        Model.getInstance().getDatabaseDriver().newTransaction(sender, receiver, amount, message);
        // Clear the fields
        amount_fld.setText("");
        amount_fld.setText("");
        message_fld.setText("");
    }

    // Method calculates all expenses and income
    private void accountSummary() {
        double income = 0;
        double expenses = 0;
        if (Model.getInstance().getAllTransactions().isEmpty()){
            Model.getInstance().setAllTransactions();
        }
        for (Transaction transaction: Model.getInstance().getAllTransactions()) {
            if (transaction.senderProperty().get().equals(Model.getInstance().getCustomer().accountNumberProperty().get())){
                expenses = expenses + transaction.amountProperty().get();
            } else {
                income = income + transaction.amountProperty().get();
            }
        }
        income_lbl.setText("+ $" + income);
        expense_lbl.setText("- $" + expenses);
    }
}



